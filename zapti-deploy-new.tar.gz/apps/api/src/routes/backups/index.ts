// ZapTI API — Backup Routes
import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '@zapti/database';
import { toJsonSchema } from '../../utils/zod-to-json-schema.js';

const createBackupSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  type: z.enum(['FULL', 'TENANT_DATA', 'CONFIG_ONLY']).default('FULL'),
  includeAttachments: z.boolean().default(false),
  includeMedia: z.boolean().default(false),
});

const createBackupSchemaJson = toJsonSchema(createBackupSchema);

const listBackupsQuerySchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
  type: z.enum(['FULL', 'TENANT_DATA', 'CONFIG_ONLY']).optional(),
  status: z.enum(['IN_PROGRESS', 'COMPLETED', 'FAILED']).optional(),
});

const listBackupsQuerySchemaJson = toJsonSchema(listBackupsQuerySchema);

export async function backupRoutes(app: FastifyInstance) {
  // GET /backups - List backups
  app.get('/', {
    preHandler: [app.requirePermission('backups:read')],
    schema: { querystring: listBackupsQuerySchemaJson },
  }, async (request) => {
    const { page, limit, type, status } = request.query as z.infer<typeof listBackupsQuerySchema>;
    const tenantId = request.tenant!.id;

    const where: any = { tenantId };
    if (type) where.type = type;
    if (status) where.status = status;

    const [backups, total] = await Promise.all([
      prisma.backup.findMany({
        where,
        include: { creator: { select: { id: true, name: true } } },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { startedAt: 'desc' },
      }),
      prisma.backup.count({ where }),
    ]);

    return { data: backups, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  });

  // GET /backups/stats - Backup statistics
  app.get('/stats', { preHandler: [app.requirePermission('backups:read')] }, async (request) => {
    const tenantId = request.tenant!.id;

    const [total, completed, failed, running, totalSize, lastBackup] = await Promise.all([
      prisma.backup.count({ where: { tenantId } }),
      prisma.backup.count({ where: { tenantId, status: 'COMPLETED' } }),
      prisma.backup.count({ where: { tenantId, status: 'FAILED' } }),
      prisma.backup.count({ where: { tenantId, status: 'RUNNING' } }),
      prisma.backup.aggregate({ where: { tenantId, status: 'COMPLETED' }, _sum: { fileSize: true } }),
      prisma.backup.findFirst({ where: { tenantId, status: 'COMPLETED' }, orderBy: { completedAt: 'desc' } }),
    ]);

    return {
      stats: {
        total,
        completed,
        failed,
        running,
        totalSize: totalSize._sum.fileSize ? Number(totalSize._sum.fileSize) : 0,
        lastBackup: lastBackup ? { id: lastBackup.id, name: lastBackup.type, completedAt: lastBackup.completedAt, size: lastBackup.fileSize ? Number(lastBackup.fileSize) : 0 } : null,
      },
    };
  });

  // GET /backups/:id - Get backup details
  app.get('/:id', { preHandler: [app.requirePermission('backups:read')] }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const tenantId = request.tenant!.id;

    const backup = await prisma.backup.findFirst({
      where: { id, tenantId },
      include: { creator: { select: { id: true, name: true } } },
    });

    if (!backup) {
      return reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Backup não encontrado' } });
    }

    return { backup: { ...backup, size: backup.fileSize ? Number(backup.fileSize) : null } };
  });

  // POST /backups - Create backup
  app.post('/', {
    preHandler: [app.requirePermission('backups:create')],
    schema: { body: createBackupSchemaJson },
  }, async (request, reply) => {
    const { name, type, includeAttachments, includeMedia } = request.body as z.infer<typeof createBackupSchema>;
    const tenantId = request.tenant!.id;
    const userId = request.user!.id;

    // Check if there's already a running backup
    const runningBackup = await prisma.backup.findFirst({ where: { tenantId, status: 'RUNNING' } });
    if (runningBackup) {
      return reply.status(400).send({ error: { code: 'BACKUP_RUNNING', message: 'Já existe um backup em andamento' } });
    }

    const backup = await prisma.backup.create({
      data: {
        tenantId,
        type,
        status: 'PENDING',
        metadata: JSON.stringify({ name: name || `Backup ${type} - ${new Date().toLocaleString('pt-BR')}`, includeAttachments, includeMedia }),
        createdBy: userId,
      },
    });

    // Start backup asynchronously
    runBackupAsync(backup.id, tenantId, type, includeAttachments, includeMedia, app).catch(console.error);

    await logAudit(request, 'BACKUP_STARTED', { backupId: backup.id, type });

    return reply.status(202).send({ backup, message: 'Backup iniciado' });
  });

  // POST /backups/:id/download - Download backup
  app.get('/:id/download', { preHandler: [app.requirePermission('backups:download')] }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const tenantId = request.tenant!.id;

    const backup = await prisma.backup.findFirst({ where: { id, tenantId, status: 'COMPLETED' } });
    if (!backup) {
      return reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Backup não encontrado ou não concluído' } });
    }

    if (!backup.filePath) {
      return reply.status(404).send({ error: { code: 'FILE_NOT_FOUND', message: 'Arquivo de backup não disponível' } });
    }

    // In production: stream file from storage
    // For now, return download URL
    reply.redirect(backup.filePath);
  });

  // DELETE /backups/:id - Delete backup
  app.delete('/:id', { preHandler: [app.requirePermission('backups:delete')] }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const tenantId = request.tenant!.id;

    const backup = await prisma.backup.findFirst({ where: { id, tenantId } });
    if (!backup) {
      return reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Backup não encontrado' } });
    }

    if (backup.status === 'RUNNING') {
      return reply.status(400).send({ error: { code: 'BACKUP_RUNNING', message: 'Não pode deletar backup em andamento' } });
    }

    // In production: delete file from storage
    await prisma.backup.delete({ where: { id } });

    await logAudit(request, 'BACKUP_DELETED', { backupId: id });

    return { message: 'Backup deletado' };
  });
}

async function runBackupAsync(backupId: string, tenantId: string, type: string, includeAttachments: boolean, includeMedia: boolean, app: FastifyInstance) {
  try {
    await prisma.backup.update({ where: { id: backupId }, data: { status: 'IN_PROGRESS', startedAt: new Date() } });

    const data: any = { tenantId, type, exportedAt: new Date().toISOString(), version: '1.0' };

    // Export data based on type
    switch (type) {
      case 'FULL':
        data.users = await exportUsers(tenantId);
        data.tenants = await exportTenantSettings(tenantId);
        data.contacts = await exportContacts(tenantId);
        data.conversations = await exportConversations(tenantId);
        data.messages = await exportMessages(tenantId);
        data.tickets = await exportTickets(tenantId);
        data.flows = await exportFlows(tenantId);
        data.automations = await exportAutomations(tenantId);
        data.instances = await exportInstances(tenantId);
        data.teams = await exportTeams(tenantId);
        data.tags = await exportTags(tenantId);
        data.templates = await exportTemplates(tenantId);
        break;
      case 'TENANT_DATA':
        data.contacts = await exportContacts(tenantId);
        data.conversations = await exportConversations(tenantId);
        data.messages = await exportMessages(tenantId);
        data.tickets = await exportTickets(tenantId);
        data.tags = await exportTags(tenantId);
        break;
      case 'CONFIG_ONLY':
        data.tenants = await exportTenantSettings(tenantId);
        data.flows = await exportFlows(tenantId);
        data.automations = await exportAutomations(tenantId);
        data.instances = await exportInstances(tenantId);
        data.teams = await exportTeams(tenantId);
        data.templates = await exportTemplates(tenantId);
        break;
    }

    // In production: upload to storage (S3, GCS, etc.)
    const fileName = `backup-${tenantId}-${backupId}-${Date.now()}.json`;
    const filePath = `https://storage.example.com/backups/${fileName}`;
    const size = Buffer.byteLength(JSON.stringify(data), 'utf8');

    await prisma.backup.update({
      where: { id: backupId },
      data: { status: 'COMPLETED', completedAt: new Date(), filePath, fileSize: size },
    });

    // Emit completion event
    app.emitToTenant?.(tenantId, 'backup:completed', { backupId, filePath, size });
  } catch (error: any) {
    await prisma.backup.update({
      where: { id: backupId },
      data: { status: 'FAILED', completedAt: new Date(), error: error.message },
    });

    app.emitToTenant?.(tenantId, 'backup:failed', { backupId, error: error.message });
  }
}

// Export functions
async function exportUsers(tenantId: string) {
  return prisma.userTenant.findMany({
    where: { tenantId },
    include: { user: true, teams: { include: { team: true } } },
  });
}

async function exportTenantSettings(tenantId: string) {
  return prisma.tenant.findUnique({ where: { id: tenantId } });
}

async function exportContacts(tenantId: string, since?: Date) {
  const where: any = { tenantId };
  if (since) where.updatedAt = { gte: since };
  return prisma.contact.findMany({ where });
}

async function exportConversations(tenantId: string, since?: Date) {
  const where: any = { tenantId };
  if (since) where.updatedAt = { gte: since };
  return prisma.conversation.findMany({ where });
}

async function exportMessages(tenantId: string, since?: Date) {
  const where: any = { tenantId };
  if (since) where.createdAt = { gte: since };
  return prisma.message.findMany({ where, orderBy: { createdAt: 'asc' } });
}

async function exportTickets(tenantId: string, since?: Date) {
  const where: any = { tenantId };
  if (since) where.updatedAt = { gte: since };
  return prisma.ticket.findMany({ where, include: { comments: true, attachments: true } });
}

async function exportFlows(tenantId: string) {
  return prisma.flow.findMany({ where: { tenantId } });
}

async function exportAutomations(tenantId: string) {
  return prisma.automation.findMany({ where: { tenantId } });
}

async function exportInstances(tenantId: string) {
  return prisma.whatsAppInstance.findMany({ where: { tenantId } });
}

async function exportTeams(tenantId: string) {
  return prisma.team.findMany({ where: { tenantId }, include: { members: { include: { user: true } } } });
}

async function exportTags(tenantId: string) {
  return [];
}

async function exportTemplates(tenantId: string) {
  return [];
}

async function logAudit(request: any, action: string, metadata: Record<string, any>) {
  try {
    await prisma.auditLog.create({
      data: {
        tenantId: request?.tenant?.id,
        userId: request?.user?.id,
        action,
        description: `${action} - ${metadata.backupId || metadata.scheduleId || 'unknown'}`,
        metadata: JSON.stringify({ ...metadata, ip: request?.ip || 'unknown', userAgent: request?.headers?.['user-agent'] || 'unknown' }),
      },
    });
  } catch (err) {
    console.error('Audit log error:', err);
  }
}