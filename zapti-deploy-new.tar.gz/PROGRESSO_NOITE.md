# PROGRESSO NOITE - ZapTI

Arquivo de controle de progresso para a missão noturna. Não deve ir para o GitHub (.gitignore).

---

## Estado Inicial (2026-10-06)

- Branch: master (2 commits à frente do origin)
- Último commit: `91a4d52 chore: remove unused slugify utility from shared`
- Problemas conhecidos: fontes não carregando, login/onboarding com problemas, tema com bug no hover

---

## FASE 0: BASE

### 0.1 Fontes - Concluído
- [x] Investigar causa raiz das fontes não funcionando
- [x] Escolher uma fonte (Inter), definir em local central, aplicar globalmente
- [x] Confirmar carregamento no navegador

### 0.2 Tema - Em andamento
- [x] Corrigir botão de alternar tema (quadrado cinza no hover fora do lugar) - substituído Button por button nativo com classes consistentes
- [ ] Configurações: cor de destaque, claro/escuro/auto, plano de fundo personalizável, animações (respeitando prefers-reduced-motion)

### 0.3 Login e Onboarding (CRÍTICO) - Em andamento
- [x] Corrigir props não serializáveis nos componentes do onboarding (Step1AdminForm, Step2TenantForm, Step3PreferencesForm, Step4WhatsAppForm)
- [ ] Reproduzir erro do login (console, Network, logs servidor)
- [ ] Investigar .env, rotas auth, cookies/sessão/JWT, CORS, URL base, conexão banco, middleware/guards
- [ ] Corrigir causa raiz
- [ ] Garantir onboarding com banco VAZIO funcionando
- [ ] Garantir: entrar, manter sessão, redirecionar, sair, recuperar sessão após reload - tudo via HTTPS no domínio
- [ ] Testar ponta a ponta no estado final (após Fase 7)

### 0.4 Layout Responsivo e Mobile
- [ ] Revisar layout geral para mobile/tablet/PC
- [ ] Navegação adaptada (menu inferior ou drawer)
- [ ] Áreas de toque adequadas
- [ ] Nada estourando a tela

---

## FASE 1: USUÁRIOS E SEGURANÇA
- [ ] 1. Usuários e perfis com papéis, permissões, foto de perfil
- [ ] 2. Dois nomes: login único + nome de exibição na mensagem
- [ ] 3. SMTP: tela configuração + teste, senha protegida, uso para reset/notificações/relatórios
- [ ] 4. Reset/alteração de senha por e-mail (token único, expiração curta)
- [ ] 5. 2FA por e-mail (6 dígitos, expiração, limite tentativas, opção admin obrigatório)
- [ ] 6. Audit Log: logins, alterações config, envios e-mail; tela consulta admin com filtros/CSV
- [ ] 7. Permissões visibilidade: admin escolhe quem vê cada conversa/grupo/ticket (backend)

---

## FASE 2: WHATSAPP (EVOLUTION API)
- [ ] 1. Conexão QR Code, status, reconectar/desconectar, configurações Evolution API
- [ ] 2. Contatos: sincronizar, CRUD, tags, notas, mesclar, busca
- [ ] 3. Conversas: envio/recebimento arquivos, áudio gravado navegador, foto câmera, fixar, notificações
- [ ] 4. Rejeição automática de chamadas (config ativar/desativar, mensagem opcional editável)
- [ ] 5. Grupos: aba separada, listar, conversar, enviar, permissões
- [ ] 6. Tickets: criar/fechar/reabrir, transferir entre atendentes/departamentos, histórico, notificação
- [ ] 7. Chat interno entre atendentes (direto e canal geral), notificações
- [ ] 8. Bloqueio do bot: lista contatos/números/grupos, gerenciável por tela

---

## FASE 3: BOT BUILDER
- [ ] 1. Construtor visual (drag-drop, nós: mensagem, menu, pergunta, condição, atraso, etiqueta, transferir, horário, avaliação, encerrar)
- [ ] 2. Salvar/versionar/ativar/desativar, validação, simulador
- [ ] 3. Respeitar lista bloqueio
- [ ] 4. Avaliação 1-5 + comentário, vinculada a contato/atendente/ticket, ranking dashboard
- [ ] 5. Mobile funcional

---

## FASE 4: DASHBOARD
- [ ] Gráficos: linhas, barras, rosca, mapa de calor
- [ ] Cards animados (respeitando reduzir animações)
- [ ] Métricas: mensagens, contatos, tickets, bot, avaliações, espaço disco, status operacional, tempo resposta/resolução
- [ ] Filtros globais persistentes na URL (contato, período, hora, atendente, avaliação, num mensagens)
- [ ] Exportação CSV

---

## FASE 5: FUNCIONALIDADES EXTRAS
- [ ] 1. Respostas rápidas (atalho "/")
- [ ] 2. Notas internas no ticket
- [ ] 3. Departamentos/filas com distribuição automática
- [ ] 4. Status presença atendente
- [ ] 5. Busca global
- [ ] 6. Mensagens agendadas
- [ ] 7. Rate limit login + sessões ativas
- [ ] 8. 2FA TOTP (app autenticador)
- [ ] 9. Backup automático diário banco (retenção 14 dias)
- [ ] 10. Endpoint /health
- [ ] 11. LGPD: exportar/excluir dados contato
- [ ] 12. SLA com alertas + PDF
- [ ] 13. PWA + push + atalhos teclado
- [ ] 14. API keys + webhooks

---

## FASE 6: ENTREGA
- [ ] 1. MCP Server ZapTI (/mcp-server) com tools úteis, auth por API key, README
- [ ] 2. Documentação GitHub: README completo, docs/, sem menção IA
- [ ] 3. robots.txt na raiz pública

---

## FASE 7: TESTE FINAL E LIMPEZA
- [ ] 1. Teste geral ponta a ponta (usuários zz_teste_*)
- [ ] 2. Apagar usuários zz_teste_* e dados
- [ ] 3. Limpeza total banco servidor (dump, apagar dados, manter estrutura, confirmar vazio, reiniciar app)
- [ ] 4. Verificação "primeiro acesso" com banco vazio (onboarding -> admin -> login), apagar admin teste, deixar vazio
- [ ] 5. Último commit + push + deploy final

---

## Log de Execução

### 2026-10-06 - Início
- Criado arquivo PROGRESSO_NOITE.md
- Analisado estrutura do projeto
- Identificados problemas iniciais: fontes, login/onboarding, tema

---

## FASE 0: BASE - Iniciada

### 0.1 Fontes - Em andamento
- [ ] Investigar causa raiz das fontes não funcionando
- [ ] Escolher uma fonte (Inter), definir em local central, aplicar globalmente
- [ ] Confirmar carregamento no navegador